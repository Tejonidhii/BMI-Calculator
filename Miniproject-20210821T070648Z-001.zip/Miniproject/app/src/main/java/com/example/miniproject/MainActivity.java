package com.example.miniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
EditText h1, w1;
TextView tv1,tv2;
Button bn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        h1=(EditText)findViewById(R.id.editHeight);
        w1=(EditText)findViewById(R.id.editWeight);
        tv1=(TextView)findViewById(R.id.textView);
        tv2=(TextView)findViewById(R.id.textView2);

    }

    public void calcBmi(View view) {
        double height, weight, result,h,w;
        height=Double.parseDouble(h1.getText().toString());
        weight=Double.parseDouble(w1.getText().toString());
        h=height*12;
        w=weight*2.205;
        result=(w/h)*10;
        tv1.setText(""+result);
        if(result<18.5){
            tv2.setText("under weight");
        }
        else if (result>=18.5 && result<=24.9){
            tv2.setText("normal weight");
        }
        else if (result>24.9 && result<=29.9){
            tv2.setText("over weight");
        }
        else {
            tv2.setText("obesity");
        }

    }
}